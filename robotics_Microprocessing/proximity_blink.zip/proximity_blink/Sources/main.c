#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

void output_seven_seg(int dout){
    unsigned char output[10] = {0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10};

    if(dout > 138){
      PTH = output[0]; 
    }else if(dout > 102){
      PTH = output[1]; 
    }else if(dout > 79){
      PTH = output[2]; 
    }else if(dout > 64){
      PTH = output[3]; 
    }else if(dout > 58){
      PTH = output[4]; 
    }else if(dout > 46){
      PTH = output[5]; 
    }else if(dout > 41){
      PTH = output[6]; 
    }else if(dout > 38){
      PTH = output[7]; 
    }else if(dout > 35){
      PTH = output[8]; 
    }else if(dout > 30){
      PTH = output[9]; 
    }else if(dout <= 30){
      PTH = 0xFF;
    }              
}

void proximity_setup(){
/*********************************************
 *  Setup ATD0 with proximity sensor
 *
 *
 *********************************************/
  ATD0CTL2 = 0x80;
  ATD0CTL3 = 0x48;  
  ATD0CTL4 = 0x85;   
  
}

int proximity_read(){
/*********************************************************
 *
 *   Read a digital value from the front proximity sensor
 *
 *   Returns average of front 8 conversions from ATD0
 *
 ********************************************************/
    int dout;
    ATD0CTL5 = 0b00100100;
	  while(!(ATD0STAT0 & 0x80)){
	  
      dout = ((int)ATD0DR0H + (int)ATD0DR1H + (int)ATD0DR2H +
              (int)ATD0DR3H + (int)ATD0DR4H + (int)ATD0DR5H +
              (int)ATD0DR6H + (int)ATD0DR7H) / 8;
 	  }
    return dout;
}


void main(void) {
  int dout = 0;
 
  proximity_setup();   //Setup ATD0CTL
  DDRH = 0xFF;         //Setup for 7-seg

	
	while(1){
	  dout = proximity_read();
	  output_seven_seg(dout);
	}    
}





